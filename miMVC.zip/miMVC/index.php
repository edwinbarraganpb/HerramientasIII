<?php
    require_once 'controllers/controller.php';
    require_once 'models/modelo.php';

    $miPagina = new mvcController();
    $miPagina->plantilla()
?>