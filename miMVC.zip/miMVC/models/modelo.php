<?php

class paginas{

    public static function url($action){
        switch($action){
            case 0:
                $vista = "inicio";
                break;
            case 1:
                $vista = "nosotros";
                break;
            case 2:
                $vista = "servicios";
                break;
            case 3:
                $vista = "contactenos";
                break;
            case 404:
                $vista = "error";
                break;
            default:
                $vista = "error";
                break;
        }

        $enlace = "views/".$vista.".php";
        return $enlace;

    }

}

?>