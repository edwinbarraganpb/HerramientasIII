<?php
class mvcController{

    public function plantilla(){
        include 'views/template.php';
    }

    public function paginasController(){
        if(!isset($_GET['action'])){
            $enlace = 404;
        }else{
            $enlace = $_GET['action'];
        }

        $respuesta = paginas::url($enlace);//Modelo
        include $respuesta;
    }


}

?>