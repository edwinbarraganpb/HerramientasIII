<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php?action=0">Inicio</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">

        <li class="nav-item">
          <a class="nav-link active" href="index.php?action=1">Nosotros</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php?action=2">Servicios</a>
        </li>        
        <li class="nav-item">
          <a class="nav-link" href="index.php?action=3">Contactenos</a>
        </li>        
      </ul>
    </div>
  </div>
</nav>